package interfaces;

public interface Interface {

	public abstract void setFlag(int coordX, int coordY);
	
	public abstract void openCell(int coordX, int coordY);
}
